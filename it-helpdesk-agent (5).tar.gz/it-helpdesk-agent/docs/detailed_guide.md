# 详细技术文档：IT 智能帮助台代理

本文档详细说明系统的每个文件的作用、运用的技术原理、使用方法和设计思路。

---

## 目录

1. [使用方法](#1-使用方法)
2. [各文件作用详解](#2-各文件作用详解)
3. [核心原理详解](#3-核心原理详解)
4. [数据流与调用链](#4-数据流与调用链)
5. [评估框架设计](#5-评估框架设计)
6. [生产化思考](#6-生产化思考)

---

## 1. 使用方法

### 1.1 环境准备

```bash
# 进入项目目录
cd it-helpdesk-agent

# 安装依赖（仅需 openai 库，用于调用 Ollama 的 OpenAI 兼容接口）
pip install -r requirements.txt
```

### 1.2 安装并启动 Ollama

```bash
# 1. 安装 Ollama
curl -fsSL https://ollama.com/install.sh | sh
# 或访问 https://ollama.com 下载安装包

# 2. 拉取模型（推荐 qwen2.5:7b，中文优秀且支持 function calling）
ollama pull qwen2.5:7b

# 3. 启动 Ollama 服务
ollama serve
# 默认监听 http://localhost:11434
```

**支持 function calling 的推荐模型**：
| 模型 | 大小 | 特点 |
|------|------|------|
| `qwen2.5:7b` | 4.7GB | 中文最佳，function calling 支持好 |
| `llama3.1:8b` | 4.7GB | 英文优秀，Meta 出品 |
| `mistral:7b` | 4.1GB | 快速，支持工具调用 |
| `qwen2.5:14b` | 9GB | 更强推理，需要更多显存 |

### 1.3 启动代理

```bash
# 直接运行（默认连接本地 Ollama + qwen2.5:7b）
python main.py

# 指定模型
AGENT_MODEL=llama3.1:8b python main.py

# 连接远程 Ollama
OPENAI_BASE_URL=http://192.168.1.100:11434/v1 python main.py

# 也可以连接 OpenAI 官方 API（如果有的话）
OPENAI_API_KEY=sk-... AGENT_MODEL=gpt-4o python main.py
```

启动后进入对话式交互。示例对话：

```
👤 You: 我无法登录 Okta，试了重置密码但还是不行，30 分钟后有客户会议

🤖 Agent: 我来帮你排查这个问题。让我先查一下 Okta 的服务状态和相关文档...
   [调用工具: check_service_status, search_knowledge_base]
   
   我发现两个情况：
   1. Okta SSO 目前处于"降级"状态 —— MFA 推送通知有 30-60 秒延迟
   2. 你的账户可能因为多次尝试被锁定

   请告诉我你的邮箱地址，我查一下你的账户状态？

👤 You: sarah.chen@yourcompany.com

🤖 Agent: [调用工具: lookup_user]
   找到了。Sarah Chen，数据工程团队。
   
   好消息是你的账户密码最近修改过（3月1日），MFA 已注册。
   
   建议你：
   1. 等待 30 分钟让账户自动解锁
   2. 在此期间，尝试用 TOTP 验证码代替推送通知登录
   3. 如果你的 Okta 支持 TOTP，在 Okta 登录页面选择"使用验证码"
   
   如果 30 分钟后仍无法登录，请告诉我，我会升级给 IT 团队处理。
```

### 1.3 CLI 命令

| 命令 | 说明 |
|------|------|
| `/status` | 显示当前会话的完整状态（用户、问题、工具调用记录） |
| `/history` | 显示消息数量和工具调用次数 |
| `/escalate` | 手动触发升级，生成完整的上下文摘要 |
| `/reset` | 清空当前会话，开始新对话 |
| `/help` | 显示帮助信息 |
| `/quit` | 退出程序 |

### 1.4 运行测试

```bash
# 冒烟测试（验证数据源和工具，不需要 API Key）
python tests/smoke_test.py

# 集成测试（验证数据质量和推理链，不需要 API Key）
python tests/integration_test.py

# LLM 评估（需要 API Key，测试代理的完整推理能力）
python tests/evaluate.py --verbose

# 测试单个场景
python tests/evaluate.py -s TC-001 --verbose
```

---

## 2. 各文件作用详解

### 2.1 入口文件

#### `main.py`
项目入口，将 `src/` 加入 Python 路径，启动 CLI 交互循环。保持极简，所有逻辑委托给 `src/cli.py`。

### 2.2 数据层 (`data/`)

#### `data/knowledge_base/articles.json` — 知识库
**作用**：存储 IT 故障排查文章，是代理回答问题的主要依据。

**结构**：
```json
{
  "id": "KB001",
  "title": "How to Reset Your Okta Password",
  "category": "password",
  "tags": ["okta", "password", "login", "reset"],
  "content": "## Markdown 格式的操作步骤...",
  "resolution_type": "self_service",
  "last_updated": "2026-03-15"
}
```

**设计思路**：
- 每篇文章有 `category` 和 `tags` 用于搜索匹配
- `content` 是 Markdown 格式的详细操作步骤，直接给用户展示
- `resolution_type` 标记是自助解决 (`self_service`) 还是需要引导 (`guided`)
- 共 7 篇文章覆盖：密码/Okta、VPN、软件访问、Jenkins、Slack、打印机

#### `data/status/services.json` — 服务状态
**作用**：模拟实时服务健康状态和维护记录，代理用它判断是否有已知故障。

**结构**：
```json
{
  "name": "Okta SSO",
  "status": "degraded",
  "incident_details": "Elevated authentication latency...",
  "affected_components": ["MFA Push Notifications", "SSO Login"],
  "expected_resolution": "2026-04-28T16:00:00Z",
  "workaround": "Use TOTP codes instead of push notifications"
}
```

**设计思路**：
- `status` 字段：`operational` / `degraded` / `outage`
- `incident_details` 提供具体故障描述
- `workaround` 提供临时方案——代理可以直接告诉用户
- `maintenance_windows` 记录最近的维护事件，用于关联"维护后出现的问题"
- 共 8 个服务：Okta、VPN、Jenkins、Snowflake、Grafana、Salesforce、Tableau、Slack

#### `data/users/directory.json` — 用户目录
**作用**：模拟员工信息，代理用它识别用户身份、查看设备和权限。

**结构**：
```json
{
  "employee_id": "EMP001",
  "name": "Sarah Chen",
  "email": "sarah.chen@yourcompany.com",
  "department": "Data Engineering",
  "role": "Senior Data Engineer",
  "devices": [{"type": "laptop", "model": "MacBook Pro M3", "os": "macOS 15.3"}],
  "access": ["okta", "slack", "jira", "snowflake:readonly", "grafana:viewer"],
  "vpn_enabled": true,
  "mfa_enrolled": true
}
```

**设计思路**：
- 包含部门、角色、位置、设备、权限等完整信息
- `access` 列表用 `系统:权限` 格式，便于检查特定权限
- 5 个用户覆盖不同部门（工程、销售、运维、市场）和不同入职时间
- 新员工 (Alex Rivera) 权限较少，用于测试"申请权限"场景

#### `data/history/resolutions.json` — 历史方案
**作用**：记录过去已解决的 IT 问题，代理用它参考类似案例的解决方案。

**结构**：
```json
{
  "id": "RES-2026-0428-001",
  "employee_id": "EMP002",
  "issue": "Okta MFA push notifications not arriving",
  "root_cause": "Okta MFA service experiencing delays due to ongoing incident",
  "resolution": "Guided user to use TOTP code instead of push notification",
  "tools_used": ["system_status_check", "knowledge_base_search"],
  "escalated": false,
  "resolution_time_minutes": 3,
  "satisfaction": 5
}
```

**设计思路**：
- 包含完整的问题→根因→解决链
- `tools_used` 记录了哪些工具参与了诊断
- `satisfaction` 评分用于评估方案质量
- 6 条记录覆盖自助解决和需要升级的案例

#### `data/policies/rules.json` — 策略规则
**作用**：定义代理的权限边界——什么能做、什么不能做、何时升级。

**关键字段**：
- `agent_can_do`：允许的操作列表（查状态、查用户、搜 KB、解释流程）
- `agent_cannot_do`：禁止的操作列表（改密码、改权限、改基础设施）
- `escalation_criteria`：升级触发条件（多人故障、安全事件、超出能力）
- `data_access_rules`：数据访问权限（能看什么、不能看什么）

### 2.3 源码层 (`src/`)

#### `src/data/loader.py` — 数据访问层
**作用**：加载所有 JSON 数据源，提供统一的查询接口。

**核心类 `DataLoader`**：
- 懒加载：首次访问时才读取文件
- `search_knowledge_base(query, category)` — 关键词匹配搜索，按相关性评分排序
- `get_service_status(service_name)` — 获取服务状态
- `get_user_info(identifier)` — 按邮箱/工号/姓名查找用户
- `search_resolutions(query, category)` — 搜索历史方案
- `check_user_access(user_id, system)` — 检查用户对特定系统的权限

**搜索算法**：基于关键词匹配的简单评分系统：
- 标题匹配 +3 分
- 标签匹配 +2 分
- 内容匹配 +1 分
- 按总分排序，返回前 3 条

#### `src/tools/registry.py` — 工具注册表
**作用**：定义代理可调用的工具（schema + 实现），是连接 LLM 和数据层的桥梁。

**包含 7 个工具**：

| 工具名 | 作用 | 参数 |
|--------|------|------|
| `search_knowledge_base` | 搜索知识库文章 | `query`, `category?` |
| `check_service_status` | 查服务状态 | `service_name?` |
| `lookup_user` | 查员工信息 | `identifier` |
| `check_user_access` | 查用户权限 | `user_identifier`, `system` |
| `search_resolution_history` | 搜历史方案 | `query`, `category?` |
| `get_maintenance_logs` | 获取维护记录 | 无 |
| `get_agent_policies` | 获取策略规则 | 无 |

**两部分组成**：
1. `TOOL_SCHEMAS`：OpenAI Function Calling 格式的工具描述（传给 LLM）
2. `execute_tool(name, arguments)`：工具执行函数（实际查询数据）

#### `src/agent/core.py` — 代理核心
**作用**：实现推理循环，是整个系统的大脑。

**类 `ITAgent`**：
- `new_session()` — 创建新会话
- `chat(state, user_message)` — 处理用户消息，返回代理回复
- `generate_escalation_summary(state)` — 生成升级摘要

**推理循环** (`chat` 方法)：
```
1. 用户消息 → 加入对话历史
2. 构建消息列表（系统提示 + 上下文 + 历史）
3. 调用 OpenAI API（带工具定义）
4. 如果 LLM 返回工具调用：
   a. 执行工具
   b. 将结果加入对话
   c. 回到步骤 3（继续推理）
5. 如果 LLM 返回文本回复：结束循环，返回回复
```

**系统提示词** (`SYSTEM_PROMPT`) 定义了代理的角色、工作方式、能力边界和沟通风格。这是代理行为的核心控制。

#### `src/utils/conversation.py` — 对话状态管理
**作用**：追踪整个对话过程中的所有状态信息。

**类 `ConversationState`** 跟踪的信息：
- `messages` — 完整消息历史
- `identified_user` — 识别出的用户
- `identified_issue` — 识别出的问题
- `issue_category` — 问题分类
- `tools_called` — 已调用的工具列表
- `diagnosis_steps` — 诊断步骤记录
- `resolution_attempted` — 已尝试的解决方案
- `escalated` — 是否已升级
- `confidence_level` — 置信度

**为什么需要状态管理？**
- 避免重复调用相同工具
- 支持生成升级摘要（需要知道"做了什么"）
- 让代理知道"我已经查过了"，推进对话

#### `src/cli.py` — CLI 界面
**作用**：终端交互界面，处理用户输入、显示代理回复、执行命令。

**功能**：
- 彩色终端输出（ANSI 颜色码）
- 命令处理（`/status`, `/escalate` 等）
- 工具调用进度显示
- 升级摘要格式化显示
- 错误处理和会话重置

### 2.4 测试层 (`tests/`)

#### `tests/smoke_test.py` — 冒烟测试
**作用**：验证数据源加载和工具执行是否正常，不需要 API Key。

**测试内容**：
- 7 个数据源是否正确加载
- 7 个工具是否能正常执行
- 7 个工具 schema 是否格式正确
- 边界情况（用户不存在时返回什么）

#### `tests/integration_test.py` — 集成测试
**作用**：验证数据质量——搜索结果是否合理、权限检查是否正确。

**测试内容**：
- KB 搜索：5 个查询是否返回正确数量和相关性的结果
- 服务状态：8 个服务是否正确加载，降级服务是否标记正确
- 用户查找：5 个查找场景（按邮箱、工号、姓名、不存在的用户）
- 权限检查：4 个权限场景（有权限、无权限、不同系统）
- 历史方案：搜索是否返回相关记录
- 对话状态：状态管理是否正确工作

#### `tests/evaluate.py` — LLM 评估框架
**作用**：用 10 个预定义场景测试代理的完整推理能力（需要 API Key）。

**评分体系**（每场景 100 分）：

| 维度 | 分值 | 评估方式 |
|------|------|---------|
| 工具使用 | 25 | 代理是否调用了预期的工具 |
| 分类识别 | 15 | 是否正确归类问题 |
| 升级决策 | 25 | 该升则升，不该升不升 |
| 回答质量 | 20 | 回应是否包含关键词/信息 |
| 诊断参与 | 15 | 是否追问、跟踪状态 |

---

## 3. 核心原理详解

### 3.1 Agentic AI 与传统 Chatbot 的区别

**传统 Chatbot**：
```
用户输入 → 模式匹配/意图识别 → 模板回复
```
- 单轮处理，无法追问
- 无法调用外部工具
- 回答基于训练数据，可能过时

**Agentic AI（本系统）**：
```
用户输入 → LLM 推理 → 决定调用工具 → 获取结果 → 继续推理 → ... → 最终回复
```
- 多轮推理，动态调整策略
- 调用工具获取实时数据
- 回答基于真实数据源，有据可查

### 3.2 Function Calling 机制

本系统使用 OpenAI 的 Function Calling 实现工具调用：

**第一步：定义工具 schema**
```python
{
    "type": "function",
    "function": {
        "name": "search_knowledge_base",
        "description": "Search the IT knowledge base...",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search keywords"}
            },
            "required": ["query"]
        }
    }
}
```

**第二步：LLM 决定调用什么**
当用户说"我 VPN 断了"，LLM 分析后可能返回：
```json
{
    "tool_calls": [{
        "function": {
            "name": "search_knowledge_base",
            "arguments": "{\"query\": \"VPN disconnect\"}"
        }
    }, {
        "function": {
            "name": "check_service_status",
            "arguments": "{\"service_name\": \"VPN\"}"
        }
    }]
}
```
注意：LLM 可以同时请求多个工具调用。

**第三步：执行工具并返回结果**
```python
result = execute_tool("search_knowledge_base", {"query": "VPN disconnect"})
# 将结果作为 tool message 加入对话，让 LLM 继续推理
```

**第四步：LLM 基于工具结果继续推理**
LLM 看到 KB 文章和服务状态后，生成最终回复。

### 3.3 对话状态机

对话经历以下阶段：

```
[开始] → [理解问题] → [识别用户] → [调查诊断] → [提供方案] → [确认解决] → [结束]
                                    ↓
                              [升级给人工] → [生成摘要] → [结束]
```

每个阶段代理会：
1. **理解问题**：分析用户描述，提取关键词
2. **识别用户**：如果需要，查找用户信息
3. **调查诊断**：调用 KB、状态、历史等工具
4. **提供方案**：基于调查结果给出操作步骤
5. **确认解决**：询问用户是否解决了
6. **升级**：如果无法解决，生成完整上下文给人工

### 3.4 升级判断逻辑

代理通过以下信号判断是否需要升级：

**硬性规则**（在系统提示中定义）：
- 需要密码重置/账户解锁 → 必须升级
- 多人同时受影响 → 必须升级
- 安全事件 → 必须升级

**软性判断**（由 LLM 推理）：
- 所有排查步骤用尽仍无法解决
- 用户明确要求人工
- 问题超出知识库覆盖范围

**升级摘要生成**：
```python
def generate_escalation_summary(state):
    # 包含：会话ID、用户信息、问题描述、
    #       诊断步骤、已尝试方案、工具调用记录、
    #       最近对话摘要
```

### 3.5 搜索算法

知识库搜索使用简单的关键词匹配评分：

```python
score = 0
for word in query.split():
    if word in article["title"]:    score += 3  # 标题权重最高
    if word in article["tags"]:     score += 2  # 标签次之
    if word in article["content"]:  score += 1  # 内容最低
```

**为什么不用向量搜索？**
- 数据量小（7 篇文章），关键词匹配足够
- 无外部依赖（不需要 embedding 模型）
- 可解释性好（能说明为什么匹配）
- 生产环境可以替换为向量搜索

### 3.6 安全设计

**数据访问控制**：
- 代理只能读取数据，不能修改
- 用户查找只返回 IT 支持相关的字段（不返回敏感信息）
- 工具执行有异常捕获，不会泄露内部错误

**行为约束**：
- 系统提示明确禁止编造解决方案
- 策略层定义了"能做"和"不能做"的明确边界
- 代理被要求对自己的置信度保持透明

---

## 4. 数据流与调用链

### 4.1 典型对话的数据流

用户说："我 VPN 每 10 分钟断一次，上周维护后开始的"

```
1. CLI 接收输入
   ↓
2. Agent.chat() 构建消息列表
   ↓
3. 调用 OpenAI API（带 7 个工具定义）
   ↓
4. LLM 返回 tool_calls:
   - search_knowledge_base("VPN disconnect")
   - check_service_status("VPN")
   - get_maintenance_logs()
   ↓
5. 依次执行工具:
   - execute_tool("search_knowledge_base") → 返回 KB002 文章
   - execute_tool("check_service_status") → VPN 状态 operational
   - execute_tool("get_maintenance_logs") → 4月25日网络维护记录
   ↓
6. 工具结果加入对话，再次调用 LLM
   ↓
7. LLM 推理:
   - KB 文章提到 IPv6 冲突可能导致频繁断连
   - 维护记录显示上周五有网络维护
   - VPN 当前状态正常，不是服务端问题
   ↓
8. LLM 返回回复:
   "根据排查，你的问题可能与上周维护后的 IPv6 配置冲突有关。
    请尝试以下步骤：..."
   ↓
9. CLI 格式化显示回复
```

### 4.2 工具调用链示例

**场景：用户说"我无法登录 Okta"**

| 轮次 | LLM 决策 | 工具调用 | 返回结果 |
|------|---------|---------|---------|
| 1 | 需要了解问题详情 + 查服务状态 | `search_knowledge_base("Okta login")` | KB001, KB005 |
| 1 | 同时查服务状态 | `check_service_status("Okta")` | 状态: degraded |
| 2 | 需要查用户信息 | `lookup_user("sarah.chen")` | 用户详情 |
| 2 | 查看类似历史 | `search_resolution_history("Okta MFA")` | RES-2026-0428-001 |
| 3 | 综合所有信息回复 | 无 | 最终回答 |

---

## 5. 评估框架设计

### 5.1 评估维度

评估不是简单的"对/错"，而是多维度打分：

**工具使用 (25分)**：代理是否调用了正确的工具？
- 期望调用 `search_knowledge_base` + `check_service_status` → 实际调用了 → 满分
- 期望调用但没调用 → 扣分
- 不期望调用但调用了（如无关工具）→ 适当扣分

**分类识别 (15分)**：是否正确归类问题？
- VPN 问题归类为 "vpn" → 满分
- VPN 问题归类为 "password" → 0 分

**升级决策 (25分)**：该升则升，不该升不升？
- 需要升级的场景 → 代理升级了 → 满分
- 不需要升级的场景 → 代理没升级 → 满分
- 反之扣分

**回答质量 (20分)**：回应是否包含相关信息？
- 检查关键词：如 VPN 场景应提到 "IPv6"、"GlobalProtect" 等
- 匹配度越高，分越高

**诊断参与 (15分)**：是否主动追问、跟踪状态？
- 多轮对话 + 使用工具 → 满分
- 单轮直接回答（无工具）→ 适当扣分

### 5.2 测试场景设计原则

10 个场景覆盖以下维度：

| 维度 | 场景 |
|------|------|
| 问题类型 | 密码、VPN、软件、硬件、权限、DevOps |
| 解决路径 | 自助解决、需要引导、必须升级 |
| 信息完整性 | 完整描述、模糊描述、部分信息 |
| 影响范围 | 单人、多人 |
| 时间敏感度 | 紧急、普通 |

### 5.3 如何解读评估结果

- **80%+ 整体得分**：代理表现优秀，可投入试用
- **60-80%**：代理基本可用，需要改进某些场景
- **<60%**：代理需要重大改进

**单场景分析**：
- 工具使用得分低 → 检查系统提示是否清楚描述了何时用什么工具
- 升级决策得分低 → 检查升级条件是否明确
- 回答质量得分低 → 检查知识库内容是否充分

---

## 6. 生产化思考

### 6.1 从演示到生产需要什么

| 组件 | 演示版 | 生产版 |
|------|--------|--------|
| 界面 | CLI | Slack/Teams 机器人 |
| 认证 | 用户自报身份 | SSO 集成 |
| 数据源 | JSON 文件 | API 调用（Confluence, StatusPage, Okta） |
| 升级 | 打印摘要 | ServiceNow API 创建工单 + Slack 通知 |
| 存储 | 内存 | 数据库（对话日志、分析） |
| 并发 | 单用户 | Web 框架管理多会话 |
| 模型 | OpenAI API | 可选本地模型降低成本 |

### 6.2 关键生产考量

**可观测性**：
- 记录每次工具调用的输入/输出/耗时
- 记录 LLM 的推理过程（选择了什么工具、为什么）
- 对话完成后的满意度调查

**成本控制**：
- 缓存知识库文章（不需要每次重新搜索）
- 简单问题用便宜模型（如 gpt-4o-mini）
- 批量查询服务状态（而非每次单独查）

**可靠性**：
- 工具调用超时处理
- LLM API 失败时的降级策略
- 数据源不可用时的错误提示

**合规**：
- 对话日志保留策略
- 用户数据隐私保护
- 审计追踪（谁在什么时候做了什么）

### 6.3 扩展方向

1. **多语言支持**：系统提示支持中英文切换
2. **语音交互**：接入语音识别/合成，支持电话拨打
3. **主动监控**：检测到服务故障时主动通知可能受影响的用户
4. **知识库自动生成**：从解决方案中自动提取新文章
5. **满意度闭环**：收集反馈 → 更新知识库 → 提升解决率

---

## 附录：技术栈

| 组件 | 技术 | 说明 |
|------|------|------|
| LLM | Ollama (本地) | 默认 qwen2.5:7b，也支持 OpenAI API |
| 工具编排 | Function Calling | OpenAI 兼容格式，Ollama 原生支持 |
| 数据格式 | JSON | 轻量、可读、易于替换为 API |
| CLI | Python + ANSI colors | 简单、无外部依赖 |
| 评估 | 自定义框架 | 基于规则的多维度评分 |
