"""Tools available to the IT Help Desk Agent."""
