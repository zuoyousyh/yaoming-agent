"""
Tool definitions and implementations for the IT Help Desk Agent.
Each tool has: name, description (for LLM), parameter schema, and implementation.
"""
import json
from typing import Any
from src.data.loader import get_data


# ── Tool Schemas (OpenAI function calling format) ──────────────────────

TOOL_SCHEMAS = [
    {
        "type": "function",
        "function": {
            "name": "search_knowledge_base",
            "description": "Search the IT knowledge base for troubleshooting articles, guides, and FAQs. Use this when you need to find documentation about how to resolve an IT issue.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search keywords related to the IT issue (e.g., 'VPN disconnect', 'password reset Okta')"
                    },
                    "category": {
                        "type": "string",
                        "description": "Optional category filter: password, vpn, access, devops, software, hardware",
                        "enum": ["password", "vpn", "access", "devops", "software", "hardware"]
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "check_service_status",
            "description": "Check the current operational status of IT services (Okta, VPN, Jenkins, Snowflake, Salesforce, etc.). Use this to check for outages, incidents, or degraded services.",
            "parameters": {
                "type": "object",
                "properties": {
                    "service_name": {
                        "type": "string",
                        "description": "Name of the service to check (e.g., 'Okta', 'VPN', 'Jenkins', 'Snowflake'). Omit to check all services."
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "lookup_user",
            "description": "Look up employee information by name, email, or employee ID. Returns department, role, devices, and current system access.",
            "parameters": {
                "type": "object",
                "properties": {
                    "identifier": {
                        "type": "string",
                        "description": "Employee name, email address, or employee ID"
                    }
                },
                "required": ["identifier"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "check_user_access",
            "description": "Check whether a specific employee currently has access to a particular system or service.",
            "parameters": {
                "type": "object",
                "properties": {
                    "user_identifier": {
                        "type": "string",
                        "description": "Employee name, email, or ID"
                    },
                    "system": {
                        "type": "string",
                        "description": "System name to check (e.g., 'Snowflake', 'Grafana', 'Jenkins')"
                    }
                },
                "required": ["user_identifier", "system"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_resolution_history",
            "description": "Search past IT issue resolutions for similar problems. Useful for finding how previous instances of the same issue were resolved.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Description of the issue to find similar past resolutions"
                    },
                    "category": {
                        "type": "string",
                        "description": "Optional category filter",
                        "enum": ["password", "vpn", "access", "devops", "software", "hardware"]
                    }
                },
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_maintenance_logs",
            "description": "Get recent and upcoming maintenance windows. Useful to check if a current issue might be related to recent infrastructure changes.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_agent_policies",
            "description": "Get the agent's authorization policies - what actions the agent can and cannot perform, and escalation criteria.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    }
]


# ── Tool Implementations ───────────────────────────────────────────────

def execute_tool(name: str, arguments: dict[str, Any]) -> str:
    """Execute a tool by name with given arguments. Returns JSON string."""
    data = get_data()

    try:
        if name == "search_knowledge_base":
            results = data.search_knowledge_base(
                query=arguments["query"],
                category=arguments.get("category")
            )
            if not results:
                return json.dumps({"results": [], "message": "No relevant articles found."})
            return json.dumps({"results": results, "count": len(results)})

        elif name == "check_service_status":
            results = data.get_service_status(arguments.get("service_name"))
            if not results:
                return json.dumps({"results": [], "message": "No matching services found."})
            return json.dumps({"results": results, "count": len(results)})

        elif name == "lookup_user":
            user = data.get_user_info(arguments["identifier"])
            if not user:
                return json.dumps({"found": False, "message": f"No user found matching '{arguments['identifier']}'"})
            # Don't expose all fields - just what's relevant for IT support
            safe_user = {
                "name": user["name"],
                "email": user["email"],
                "employee_id": user["employee_id"],
                "department": user["department"],
                "role": user["role"],
                "location": user["location"],
                "manager": user["manager"],
                "devices": user["devices"],
                "access": user["access"],
                "vpn_enabled": user["vpn_enabled"],
                "mfa_enrolled": user["mfa_enrolled"],
                "last_password_change": user["last_password_change"]
            }
            return json.dumps({"found": True, "user": safe_user})

        elif name == "check_user_access":
            result = data.check_user_access(
                arguments["user_identifier"],
                arguments["system"]
            )
            return json.dumps(result)

        elif name == "search_resolution_history":
            results = data.search_resolutions(
                query=arguments["query"],
                category=arguments.get("category")
            )
            if not results:
                return json.dumps({"results": [], "message": "No similar past resolutions found."})
            return json.dumps({"results": results, "count": len(results)})

        elif name == "get_maintenance_logs":
            logs = data.get_maintenance_logs()
            return json.dumps({"maintenance_windows": logs})

        elif name == "get_agent_policies":
            policies = data.get_policies()
            return json.dumps(policies)

        else:
            return json.dumps({"error": f"Unknown tool: {name}"})

    except Exception as e:
        return json.dumps({"error": f"Tool execution failed: {str(e)}"})
