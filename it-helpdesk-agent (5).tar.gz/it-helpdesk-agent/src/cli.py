"""
CLI interface for the IT Help Desk Agent.
Powered by local Ollama models.
"""
from __future__ import annotations
import sys
import os
import json
import urllib.request
from datetime import datetime

from src.agent.core import ITAgent
from src.utils.conversation import ConversationState


# ── Colors for terminal output ─────────────────────────────────────────

class C:
    """ANSI color codes."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    GREEN = "\033[32m"
    BLUE = "\033[34m"
    CYAN = "\033[36m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    MAGENTA = "\033[35m"
    WHITE = "\033[97m"
    BG_BLUE = "\033[44m"


def print_banner():
    print(f"""
{C.CYAN}{C.BOLD}╔══════════════════════════════════════════════════════════╗
║           🖥️  IT Help Desk Agent (Ollama)               ║
║           Your first stop for IT support                ║
╚══════════════════════════════════════════════════════════╝{C.RESET}

{C.DIM}Powered by local Ollama models. Describe your IT issue in natural language.
Commands: /status  /history  /escalate  /reset  /help  /quit{C.RESET}
""")


def print_agent(text: str):
    """Print agent response with formatting."""
    print(f"\n{C.GREEN}{C.BOLD}🤖 Agent:{C.RESET}")
    for line in text.split('\n'):
        print(f"   {line}")
    print()


def print_tool_call(name: str, args: dict):
    """Print a tool call indicator."""
    print(f"   {C.DIM}⚙️  Calling: {name}({', '.join(f'{k}={v}' for k, v in args.items())}){C.RESET}")


def print_escalation(summary: str):
    """Print escalation summary with special formatting."""
    print(f"\n{C.YELLOW}{C.BOLD}{'='*60}")
    print("  📋 ESCALATION SUMMARY")
    print(f"{'='*60}{C.RESET}")
    for line in summary.split('\n'):
        print(f"   {line}")
    print(f"{C.YELLOW}{'='*60}{C.RESET}\n")


def print_help():
    print(f"""
{C.CYAN}Available Commands:{C.RESET}
  /status     - Show current session status
  /history    - Show conversation message count
  /escalate   - Force escalation with full context
  /reset      - Start a new session
  /help       - Show this help
  /quit       - Exit the agent

{C.CYAN}Environment Variables:{C.RESET}
  OPENAI_BASE_URL  - Ollama endpoint (default: http://localhost:11434/v1)
  AGENT_MODEL      - Model name (default: qwen2.5:7b)
""")


def print_status(state: ConversationState):
    ctx = state.get_context_summary()
    print(f"\n{C.CYAN}Session Status:{C.RESET}")
    for k, v in ctx.items():
        print(f"  {k}: {v}")
    print()


def check_ollama(base_url: str) -> tuple[bool, list[str]]:
    """Check if Ollama is running and return available models."""
    try:
        # Strip /v1 to get Ollama base URL
        ollama_url = base_url.rstrip('/').replace('/v1', '')
        req = urllib.request.Request(f"{ollama_url}/api/tags", method='GET')
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            models = [m['name'] for m in data.get('models', [])]
            return True, models
    except Exception:
        return False, []


def main():
    """Main CLI loop."""
    print_banner()

    # Resolve config from env or defaults
    base_url = os.environ.get("OPENAI_BASE_URL", ITAgent.DEFAULT_BASE_URL)
    model = os.environ.get("AGENT_MODEL", ITAgent.DEFAULT_MODEL)

    # Check Ollama connectivity
    print(f"   {C.DIM}Connecting to Ollama at {base_url}...{C.RESET}")
    ok, available_models = check_ollama(base_url)

    if ok:
        print(f"   {C.GREEN}✅ Ollama is running{C.RESET}")
        if available_models:
            print(f"   {C.DIM}Available models: {', '.join(available_models)}{C.RESET}")
            # Check if target model is available
            model_names = [m for m in available_models]
            if not any(model in m for m in model_names):
                print(f"   {C.YELLOW}⚠️  Model '{model}' not found. Available: {', '.join(available_models[:5])}{C.RESET}")
                print(f"   {C.DIM}   Will attempt to use it anyway (Ollama may auto-pull).{C.RESET}")
        print()
    else:
        print(f"   {C.YELLOW}⚠️  Cannot reach Ollama at {base_url}{C.RESET}")
        print(f"   {C.DIM}   Make sure Ollama is running: ollama serve{C.RESET}")
        print(f"   {C.DIM}   Then pull a model:   ollama pull {model}{C.RESET}")
        print()
        choice = input(f"   Continue anyway? (y/n): ").strip().lower()
        if choice != 'y':
            sys.exit(1)

    try:
        agent = ITAgent(model=model, base_url=base_url)
    except Exception as e:
        print(f"{C.RED}Failed to initialize agent: {e}{C.RESET}")
        sys.exit(1)

    state = agent.new_session()

    # Initial greeting
    print_agent("你好！我是 IT 帮助台代理。我可以帮你解决密码问题、VPN 故障、软件权限等 IT 问题。请描述你遇到的情况。")

    while True:
        try:
            user_input = input(f"{C.BLUE}{C.BOLD}👤 You:{C.RESET} ").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n{C.DIM}Goodbye!{C.RESET}")
            break

        if not user_input:
            continue

        # Handle commands
        if user_input.startswith('/'):
            cmd = user_input.lower().split()[0]

            if cmd in ('/quit', '/exit', '/q'):
                print(f"{C.DIM}Session ended. Have a great day!{C.RESET}")
                break

            elif cmd == '/status':
                print_status(state)
                continue

            elif cmd == '/history':
                print(f"\nMessages: {len(state.messages)}, Turns: {state.turn_count}, Tools called: {len(state.tools_called)}\n")
                continue

            elif cmd == '/escalate':
                print_agent("正在为 IT 团队生成升级摘要...")
                summary = agent.generate_escalation_summary(state)
                print_escalation(summary)
                state.escalate("User requested escalation", summary)
                continue

            elif cmd == '/reset':
                state = agent.new_session()
                print_agent("会话已重置。请问有什么 IT 问题可以帮您？")
                continue

            elif cmd == '/help':
                print_help()
                continue

            else:
                print(f"{C.YELLOW}Unknown command: {cmd}. Type /help for options.{C.RESET}")
                continue

        # Normal conversation - send to agent
        try:
            response = agent.chat(state, user_input)
            print_agent(response)

            # Check if agent suggested escalation
            if state.escalated:
                summary = agent.generate_escalation_summary(state)
                print_escalation(summary)

        except Exception as e:
            err_str = str(e)
            print(f"\n{C.RED}Error: {err_str}{C.RESET}")
            if "Connection" in err_str or "refused" in err_str:
                print(f"{C.YELLOW}   Ollama 连接失败。请确认 Ollama 正在运行: ollama serve{C.RESET}")
            elif "model" in err_str.lower() and ("not found" in err_str.lower() or "404" in err_str):
                print(f"{C.YELLOW}   模型未找到。请拉取模型: ollama pull {agent.model}{C.RESET}")
            else:
                print(f"{C.DIM}Try again or type /reset to start a new session.{C.RESET}")
            print()


if __name__ == "__main__":
    main()
