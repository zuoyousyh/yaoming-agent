"""
Data loader - loads and provides access to all mock data sources.
"""
import json
import os
from pathlib import Path
from typing import Optional

DATA_DIR = Path(__file__).parent.parent.parent / "data"


def _load_json(relative_path: str) -> dict:
    filepath = DATA_DIR / relative_path
    with open(filepath, 'r') as f:
        return json.load(f)


class DataLoader:
    """Centralized access to all IT help desk data sources."""

    def __init__(self):
        self._kb = None
        self._status = None
        self._users = None
        self._history = None
        self._policies = None

    @property
    def knowledge_base(self) -> dict:
        if self._kb is None:
            self._kb = _load_json("knowledge_base/articles.json")
        return self._kb

    @property
    def service_status(self) -> dict:
        if self._status is None:
            self._status = _load_json("status/services.json")
        return self._status

    @property
    def user_directory(self) -> dict:
        if self._users is None:
            self._users = _load_json("users/directory.json")
        return self._users

    @property
    def resolution_history(self) -> dict:
        if self._history is None:
            self._history = _load_json("history/resolutions.json")
        return self._history

    @property
    def policies(self) -> dict:
        if self._policies is None:
            self._policies = _load_json("policies/rules.json")
        return self._policies

    def search_knowledge_base(self, query: str, category: Optional[str] = None) -> list[dict]:
        """Search KB articles by keyword relevance."""
        query_lower = query.lower()
        results = []
        for article in self.knowledge_base.get("articles", []):
            score = 0
            # Check title
            if any(word in article["title"].lower() for word in query_lower.split()):
                score += 3
            # Check tags
            for tag in article.get("tags", []):
                if any(word in tag.lower() for word in query_lower.split()):
                    score += 2
            # Check content
            if any(word in article["content"].lower() for word in query_lower.split()):
                score += 1
            # Category filter
            if category and article.get("category") != category:
                score = max(0, score - 5)
            if score > 0:
                results.append({**article, "relevance_score": score})
        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results[:3]  # Top 3 most relevant

    def get_service_status(self, service_name: Optional[str] = None) -> list[dict]:
        """Get status of all services or a specific one."""
        services = self.service_status.get("services", [])
        if service_name:
            name_lower = service_name.lower()
            return [s for s in services if name_lower in s["name"].lower()]
        return services

    def get_user_info(self, identifier: str) -> Optional[dict]:
        """Look up user by email, employee ID, or name."""
        users = self.user_directory.get("users", [])
        identifier_lower = identifier.lower()
        for user in users:
            if (identifier_lower in user.get("email", "").lower() or
                identifier_lower in user.get("employee_id", "").lower() or
                identifier_lower in user.get("name", "").lower()):
                return user
        return None

    def search_resolutions(self, query: str, category: Optional[str] = None) -> list[dict]:
        """Search past resolutions for similar issues."""
        query_lower = query.lower()
        results = []
        for res in self.resolution_history.get("resolutions", []):
            score = 0
            if any(word in res.get("issue", "").lower() for word in query_lower.split()):
                score += 3
            if any(word in res.get("root_cause", "").lower() for word in query_lower.split()):
                score += 2
            if any(word in res.get("resolution", "").lower() for word in query_lower.split()):
                score += 1
            if category and res.get("category") == category:
                score += 2
            if score > 0:
                results.append({**res, "relevance_score": score})
        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results[:3]

    def get_maintenance_logs(self) -> list[dict]:
        """Get recent maintenance windows."""
        return self.service_status.get("maintenance_windows", [])

    def check_user_access(self, user_id: str, system: str) -> dict:
        """Check if a user has access to a specific system."""
        user = self.get_user_info(user_id)
        if not user:
            return {"found": False, "error": "User not found"}
        user_access = user.get("access", [])
        has_access = any(system.lower() in a.lower() for a in user_access)
        return {
            "found": True,
            "user": user["name"],
            "has_access": has_access,
            "current_access": user_access,
            "system_requested": system
        }

    def get_policies(self) -> dict:
        """Get agent authorization policies."""
        return self.policies


# Singleton
_data = None

def get_data() -> DataLoader:
    global _data
    if _data is None:
        _data = DataLoader()
    return _data
