"""Conversation state management."""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class ConversationState:
    """Tracks the full state of an IT support conversation."""

    session_id: str
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    messages: list[dict] = field(default_factory=list)
    identified_user: Optional[str] = None
    identified_issue: Optional[str] = None
    issue_category: Optional[str] = None
    tools_called: list[str] = field(default_factory=list)
    diagnosis_steps: list[str] = field(default_factory=list)
    resolution_attempted: list[str] = field(default_factory=list)
    escalated: bool = False
    escalation_context: Optional[dict] = None
    turn_count: int = 0
    confidence_level: str = "low"  # low, medium, high

    def add_message(self, role: str, content: str, tool_calls: Optional[list] = None, tool_call_id: Optional[str] = None):
        msg = {"role": role, "content": content}
        if tool_calls:
            msg["tool_calls"] = tool_calls
        if tool_call_id:
            msg["tool_call_id"] = tool_call_id
        self.messages.append(msg)
        if role == "user":
            self.turn_count += 1

    def add_tool_call(self, tool_name: str):
        self.tools_called.append(tool_name)

    def add_diagnosis_step(self, step: str):
        self.diagnosis_steps.append(step)

    def add_resolution_attempt(self, attempt: str):
        self.resolution_attempted.append(attempt)

    def set_user(self, user_id: str):
        self.identified_user = user_id

    def set_issue(self, issue: str, category: Optional[str] = None):
        self.identified_issue = issue
        if category:
            self.issue_category = category

    def escalate(self, reason: str, summary: str):
        self.escalated = True
        self.escalation_context = {
            "reason": reason,
            "summary": summary,
            "user": self.identified_user,
            "issue": self.identified_issue,
            "category": self.issue_category,
            "diagnosis_steps": self.diagnosis_steps,
            "resolution_attempted": self.resolution_attempted,
            "tools_called": list(set(self.tools_called)),
            "turn_count": self.turn_count,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def get_context_summary(self) -> dict:
        return {
            "session_id": self.session_id,
            "turn_count": self.turn_count,
            "identified_user": self.identified_user,
            "identified_issue": self.identified_issue,
            "issue_category": self.issue_category,
            "tools_called": list(set(self.tools_called)),
            "diagnosis_steps_count": len(self.diagnosis_steps),
            "resolution_attempted_count": len(self.resolution_attempted),
            "escalated": self.escalated,
            "confidence_level": self.confidence_level
        }
