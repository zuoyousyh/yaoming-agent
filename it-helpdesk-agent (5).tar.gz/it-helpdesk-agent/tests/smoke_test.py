#!/usr/bin/env python3
"""
Quick smoke test - validates data sources and tool execution without API key.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.data.loader import get_data
from src.tools.registry import execute_tool, TOOL_SCHEMAS


def test_data_sources():
    """Validate all data sources load correctly."""
    data = get_data()
    tests = []

    # Knowledge base
    articles = data.knowledge_base.get("articles", [])
    tests.append(("KB articles loaded", len(articles) >= 5))
    tests.append(("KB has tags", all("tags" in a for a in articles)))

    # Service status
    services = data.service_status.get("services", [])
    tests.append(("Services loaded", len(services) >= 5))
    tests.append(("Has maintenance logs", len(data.get_maintenance_logs()) > 0))

    # User directory
    users = data.user_directory.get("users", [])
    tests.append(("Users loaded", len(users) >= 3))

    # Resolution history
    resolutions = data.resolution_history.get("resolutions", [])
    tests.append(("Resolutions loaded", len(resolutions) >= 3))

    # Policies
    policies = data.get_policies()
    tests.append(("Policies has agent_can_do", "agent_can_do" in policies.get("policies", {})))

    return tests


def test_tools():
    """Validate all tools execute correctly."""
    tests = []

    # KB search
    result = execute_tool("search_knowledge_base", {"query": "VPN disconnect"})
    tests.append(("KB search returns results", '"results"' in result and '"id"' in result))

    # Service status
    result = execute_tool("check_service_status", {"service_name": "Okta"})
    tests.append(("Status check returns Okta", '"Okta SSO"' in result))

    # All services
    result = execute_tool("check_service_status", {})
    tests.append(("All status returns multiple", '"count"' in result))

    # User lookup
    result = execute_tool("lookup_user", {"identifier": "sarah.chen"})
    tests.append(("User lookup finds Sarah", '"Sarah Chen"' in result))

    # User not found
    result = execute_tool("lookup_user", {"identifier": "nonexistent"})
    tests.append(("User lookup handles not found", '"found": false' in result.lower() or '"found":false' in result.lower()))

    # Access check
    result = execute_tool("check_user_access", {"user_identifier": "EMP001", "system": "Snowflake"})
    tests.append(("Access check returns result", '"has_access"' in result))

    # Resolution history
    result = execute_tool("search_resolution_history", {"query": "VPN disconnect"})
    tests.append(("Resolution search works", '"results"' in result))

    # Maintenance logs
    result = execute_tool("get_maintenance_logs", {})
    tests.append(("Maintenance logs work", '"maintenance_windows"' in result))

    # Policies
    result = execute_tool("get_agent_policies", {})
    tests.append(("Policies returns data", '"agent_can_do"' in result))

    return tests


def test_tool_schemas():
    """Validate tool schemas are well-formed."""
    tests = []
    tests.append(("Has 7 tool schemas", len(TOOL_SCHEMAS) == 7))
    for schema in TOOL_SCHEMAS:
        name = schema["function"]["name"]
        tests.append((f"Schema {name} has description", bool(schema["function"].get("description"))))
        tests.append((f"Schema {name} has parameters", "parameters" in schema["function"]))
    return tests


def main():
    print("🧪 IT Help Desk Agent - Smoke Tests\n")

    all_tests = []
    all_tests.extend(("Data: " + name, result) for name, result in test_data_sources())
    all_tests.extend(("Tool: " + name, result) for name, result in test_tools())
    all_tests.extend(("Schema: " + name, result) for name, result in test_tool_schemas())

    passed = sum(1 for _, r in all_tests if r)
    total = len(all_tests)

    for name, result in all_tests:
        status = "✅" if result else "❌"
        print(f"  {status} {name}")

    print(f"\n{'='*50}")
    print(f"  Results: {passed}/{total} passed")

    if passed == total:
        print("  🎉 All tests passed!")
        return 0
    else:
        print("  ⚠️  Some tests failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
