"""
Evaluation framework for the IT Help Desk Agent.

Defines test scenarios with expected behaviors, then runs them against the agent
and scores the results.
"""
from __future__ import annotations
import json
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.agent.core import ITAgent
from src.utils.conversation import ConversationState


# ── Test Scenarios ─────────────────────────────────────────────────────

@dataclass
class TestScenario:
    """A test scenario with conversation turns and expected outcomes."""
    id: str
    name: str
    description: str
    category: str
    conversation: list[dict]
    expected_tools: list[str] = field(default_factory=list)
    expected_category: Optional[str] = None
    should_escalate: bool = False
    should_resolve: bool = True
    expected_keywords_in_response: list[str] = field(default_factory=list)
    max_turns: int = 5


TEST_SCENARIOS = [


# ── Test Scenarios ─────────────────────────────────────────────────────

TEST_SCENARIOS = [
    TestScenario(
        id="TC-001",
        name="Password/Okta Login Issue",
        description="User cannot log into Okta, tried password reset, urgent meeting",
        category="password",
        conversation=[
            {
                "role": "user",
                "content": "I can't log into Okta. I tried resetting my password but it still doesn't work. I have a client meeting in 30 minutes and urgently need access.",
                "expect_tools": ["search_knowledge_base", "check_service_status"]
            },
            {
                "role": "user",
                "content": "My email is sarah.chen@yourcompany.com. The reset email came but the new password doesn't work."
            },
            {
                "role": "user",
                "content": "I'm getting 'account locked' after trying a few times."
            }
        ],
        expected_tools=["search_knowledge_base", "check_service_status", "lookup_user"],
        expected_category="password",
        should_resolve=True,
        expected_keywords_in_response=["locked", "wait", "unlock", "TOTP"]
    ),
    TestScenario(
        id="TC-002",
        name="VPN Frequent Disconnections",
        description="Remote worker's VPN drops every 10-15 minutes",
        category="vpn",
        conversation=[
            {
                "role": "user",
                "content": "My VPN keeps disconnecting every 10-15 minutes. I'm working remotely and can't access internal tools reliably.",
                "expect_tools": ["search_knowledge_base", "check_service_status"]
            },
            {
                "role": "user",
                "content": "I'm using GlobalProtect on a MacBook. It started happening after the IT maintenance last weekend."
            }
        ],
        expected_tools=["search_knowledge_base", "check_service_status", "get_maintenance_logs"],
        expected_category="vpn",
        should_resolve=True,
        expected_keywords_in_response=["IPv6", "GlobalProtect", "protocol"]
    ),
    TestScenario(
        id="TC-003",
        name="Software Access Request - Snowflake",
        description="New team member needs Snowflake and Grafana access",
        category="access",
        conversation=[
            {
                "role": "user",
                "content": "I just joined the data engineering team and need access to Snowflake production database and our Grafana dashboards.",
                "expect_tools": ["search_knowledge_base", "lookup_user"]
            },
            {
                "role": "user",
                "content": "I'm Alex Rivera, started last Monday. My manager is David Park."
            }
        ],
        expected_tools=["search_knowledge_base", "lookup_user", "check_user_access"],
        expected_category="access",
        should_resolve=True,
        expected_keywords_in_response=["request", "IT Portal", "manager", "approval"]
    ),
    TestScenario(
        id="TC-004",
        name="Service Outage Detection",
        description="User reports Salesforce slow, agent should detect known issue",
        category="software",
        conversation=[
            {
                "role": "user",
                "content": "Salesforce has been loading really slowly since yesterday. My colleague in the Chicago office is seeing the same thing.",
                "expect_tools": ["check_service_status", "search_knowledge_base"]
            }
        ],
        expected_tools=["check_service_status", "search_resolution_history"],
        expected_category="software",
        should_resolve=True,
        expected_keywords_in_response=["CDN", "Chicago", "incident"]
    ),
    TestScenario(
        id="TC-005",
        name="Post-Maintenance Jenkins Failures",
        description="Data pipeline failing after IT maintenance window",
        category="devops",
        conversation=[
            {
                "role": "user",
                "content": "Our team's automated data pipeline has been failing since Friday's IT maintenance. Jenkins jobs are timing out and downstream Tableau reports are stale.",
                "expect_tools": ["search_knowledge_base", "check_service_status", "get_maintenance_logs"]
            },
            {
                "role": "user",
                "content": "I'm Priya Patel from DevOps. The Jenkins build agents seem to be running but jobs are hanging."
            }
        ],
        expected_tools=["search_knowledge_base", "check_service_status", "get_maintenance_logs", "lookup_user"],
        expected_category="devops",
        should_resolve=True,
        expected_keywords_in_response=["workspace", "credentials", "clear", "Wipe"]
    ),
    TestScenario(
        id="TC-006",
        name="Vague Issue - Requires Clarification",
        description="User gives very vague description, agent should ask questions",
        category="general",
        conversation=[
            {
                "role": "user",
                "content": "Hey, something's not working. Can you help?"
            }
        ],
        expected_tools=[],
        should_resolve=False,
        expected_keywords_in_response=["what", "issue", "problem", "describe"]
    ),
    TestScenario(
        id="TC-007",
        name="Production Access Requires Escalation",
        description="User requests production database access - needs approval workflow",
        category="access",
        conversation=[
            {
                "role": "user",
                "content": "I need admin access to the Snowflake production database immediately. There's a data issue I need to fix.",
                "expect_tools": ["lookup_user", "check_user_access"]
            },
            {
                "role": "user",
                "content": "I'm Marcus Johnson from Sales. I know it's unusual but it's urgent for a customer deliverable."
            }
        ],
        expected_tools=["lookup_user", "check_user_access", "get_agent_policies"],
        expected_category="access",
        should_escalate=True,
        expected_keywords_in_response=["approval", "cannot", "security", "escalat"]
    ),
    TestScenario(
        id="TC-008",
        name="Multi-User Infrastructure Issue",
        description="Multiple users reporting VPN issues - potential infrastructure problem",
        category="vpn",
        conversation=[
            {
                "role": "user",
                "content": "Our entire team of 5 people is having VPN issues. We can't connect at all this morning. We're all remote.",
                "expect_tools": ["check_service_status", "search_knowledge_base"]
            },
            {
                "role": "user",
                "content": "We've all tried the basic troubleshooting. Nothing works. We're completely blocked from working."
            }
        ],
        expected_tools=["check_service_status", "search_knowledge_base"],
        expected_category="vpn",
        should_escalate=True,
        expected_keywords_in_response=["escalat", "infrastructure", "team", "multiple"]
    ),
    TestScenario(
        id="TC-009",
        name="Printer Issue - Out of Scope Deeply",
        description="User has hardware printer issue - agent should help from KB but know limits",
        category="hardware",
        conversation=[
            {
                "role": "user",
                "content": "The printer on the 3rd floor keeps jamming. I've cleared the jam but print quality is terrible now.",
                "expect_tools": ["search_knowledge_base"]
            }
        ],
        expected_tools=["search_knowledge_base"],
        expected_category="hardware",
        should_resolve=True,
        expected_keywords_in_response=["toner", "drum", "clean"]
    ),
    TestScenario(
        id="TC-010",
        name="MFA Device Lost",
        description="User lost their phone with MFA app",
        category="password",
        conversation=[
            {
                "role": "user",
                "content": "I lost my phone that had my Okta MFA app. I can't log into anything. What do I do?",
                "expect_tools": ["search_knowledge_base", "lookup_user"]
            },
            {
                "role": "user",
                "content": "I'm Jordan Lee from Marketing."
            }
        ],
        expected_tools=["search_knowledge_base", "lookup_user"],
        expected_category="password",
        should_escalate=True,
        expected_keywords_in_response=["MFA", "temporary", "bypass", "re-enroll", "contact"]
    ),
]


# ── Evaluation Runner ──────────────────────────────────────────────────

@dataclass
class ScenarioResult:
    scenario_id: str
    scenario_name: str
    passed: bool
    score: float  # 0.0 to 1.0
    details: dict
    duration_seconds: float
    tools_used: list[str]
    escalated: bool
    messages_count: int


def run_scenario(agent: ITAgent, scenario: TestScenario, verbose: bool = False) -> ScenarioResult:
    """Run a single test scenario and evaluate the result."""
    start_time = time.time()
    state = agent.new_session()
    errors = []

    if verbose:
        print(f"\n{'='*60}")
        print(f"Running: {scenario.id} - {scenario.name}")
        print(f"{'='*60}")

    # Run conversation turns
    for turn in scenario.conversation:
        user_msg = turn["content"]
        if verbose:
            print(f"\n👤 User: {user_msg}")

        try:
            response = agent.chat(state, user_msg)
            if verbose:
                print(f"🤖 Agent: {response[:200]}...")
        except Exception as e:
            errors.append(f"Error in turn: {e}")
            response = ""

    duration = time.time() - start_time

    # ── Evaluate Results ───────────────────────────────────────────
    score = 0.0
    max_score = 0.0
    details = {}

    # 1. Tool usage check (25 points)
    max_score += 25
    tools_used = list(set(state.tools_called))
    expected_tools_found = sum(1 for t in scenario.expected_tools if t in tools_used)
    if scenario.expected_tools:
        tool_score = (expected_tools_found / len(scenario.expected_tools)) * 25
    else:
        tool_score = 25 if not tools_used else 20  # Prefer no unnecessary tools for vague scenarios
    score += tool_score
    details["tool_usage"] = {
        "expected": scenario.expected_tools,
        "actual": tools_used,
        "match_ratio": expected_tools_found / max(len(scenario.expected_tools), 1),
        "score": tool_score
    }

    # 2. Category identification (15 points)
    max_score += 15
    if scenario.expected_category:
        if state.issue_category == scenario.expected_category:
            score += 15
            details["category"] = {"expected": scenario.expected_category, "actual": state.issue_category, "correct": True, "score": 15}
        else:
            details["category"] = {"expected": scenario.expected_category, "actual": state.issue_category, "correct": False, "score": 0}
    else:
        score += 10  # Partial credit if no specific category expected
        details["category"] = {"expected": None, "actual": state.issue_category, "score": 10}

    # 3. Escalation decision (25 points)
    max_score += 25
    if scenario.should_escalate:
        if state.escalated:
            score += 25
            details["escalation"] = {"expected": True, "actual": True, "correct": True, "score": 25}
        else:
            # Check if agent at least mentioned escalation in last response
            last_response = ""
            for msg in reversed(state.messages):
                if msg.get("role") == "assistant" and msg.get("content"):
                    last_response = msg["content"].lower()
                    break
            if any(word in last_response for word in ["escalat", "specialist", "human", "IT team"]):
                score += 10
                details["escalation"] = {"expected": True, "actual": "mentioned", "score": 10}
            else:
                details["escalation"] = {"expected": True, "actual": False, "correct": False, "score": 0}
    else:
        if not state.escalated:
            score += 25
            details["escalation"] = {"expected": False, "actual": False, "correct": True, "score": 25}
        else:
            details["escalation"] = {"expected": False, "actual": True, "correct": False, "score": 0}

    # 4. Response quality - keyword check (20 points)
    max_score += 20
    if scenario.expected_keywords_in_response:
        all_responses = " ".join(
            msg.get("content", "") for msg in state.messages if msg.get("role") == "assistant"
        ).lower()
        keywords_found = sum(
            1 for kw in scenario.expected_keywords_in_response if kw.lower() in all_responses
        )
        keyword_score = (keywords_found / len(scenario.expected_keywords_in_response)) * 20
        score += keyword_score
        details["keywords"] = {
            "expected": scenario.expected_keywords_in_response,
            "found": keywords_found,
            "total": len(scenario.expected_keywords_in_response),
            "score": keyword_score
        }
    else:
        score += 15  # Default partial credit
        details["keywords"] = {"score": 15}

    # 5. Diagnostic engagement (15 points)
    max_score += 15
    if state.turn_count > 1 or len(state.diagnosis_steps) > 0:
        score += 15
        details["engagement"] = {"multi_turn": state.turn_count > 1, "diagnosis_steps": len(state.diagnosis_steps), "score": 15}
    elif state.turn_count == 1 and scenario.conversation[0].get("expect_tools"):
        # Single turn but used tools - still good
        if tools_used:
            score += 10
            details["engagement"] = {"multi_turn": False, "tools_in_single_turn": True, "score": 10}
        else:
            details["engagement"] = {"multi_turn": False, "score": 0}
    else:
        score += 10  # Vague scenarios with no tools are OK
        details["engagement"] = {"score": 10}

    final_score = score / max_score if max_score > 0 else 0
    passed = final_score >= 0.6  # 60% threshold

    return ScenarioResult(
        scenario_id=scenario.id,
        scenario_name=scenario.name,
        passed=passed,
        score=final_score,
        details=details,
        duration_seconds=duration,
        tools_used=tools_used,
        escalated=state.escalated,
        messages_count=len(state.messages)
    )


def run_evaluation(agent: ITAgent, verbose: bool = False) -> list[ScenarioResult]:
    """Run all test scenarios and return results."""
    results = []
    for scenario in TEST_SCENARIOS:
        result = run_scenario(agent, scenario, verbose=verbose)
        results.append(result)
    return results


def print_evaluation_report(results: list[ScenarioResult]):
    """Print a formatted evaluation report."""
    print(f"\n{'='*70}")
    print(f"  📊 IT Help Desk Agent - Evaluation Report")
    print(f"{'='*70}\n")

    passed = sum(1 for r in results if r.passed)
    total = len(results)
    avg_score = sum(r.score for r in results) / total if total > 0 else 0

    print(f"  Overall: {passed}/{total} scenarios passed ({avg_score:.0%} avg score)\n")

    for r in results:
        status = f"{C.GREEN}✅ PASS{C.RESET}" if r.passed else f"{C.RED}❌ FAIL{C.RESET}"
        print(f"  {status} {r.scenario_id}: {r.scenario_name}")
        print(f"         Score: {r.score:.0%} | Tools: {', '.join(r.tools_used) or 'none'} | "
              f"Escalated: {r.escalated} | Duration: {r.duration_seconds:.1f}s")

        # Show details for failed scenarios
        if not r.passed:
            for key, detail in r.details.items():
                if isinstance(detail, dict) and detail.get("score", 1) < detail.get("max", 1):
                    print(f"         ⚠️  {key}: {json.dumps(detail, indent=2)[:200]}")
        print()

    # Category breakdown
    print(f"\n{'─'*70}")
    categories = {}
    for r in results:
        # Find the scenario category
        scenario = next((s for s in TEST_SCENARIOS if s.id == r.scenario_id), None)
        cat = scenario.category if scenario else "unknown"
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(r)

    print(f"  By Category:")
    for cat, cat_results in categories.items():
        cat_passed = sum(1 for r in cat_results if r.passed)
        cat_avg = sum(r.score for r in cat_results) / len(cat_results)
        print(f"    {cat}: {cat_passed}/{len(cat_results)} passed ({cat_avg:.0%} avg)")

    print(f"\n{'='*70}\n")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Evaluate the IT Help Desk Agent")
    parser.add_argument("--verbose", "-v", action="store_true", help="Show detailed conversation output")
    parser.add_argument("--scenario", "-s", type=str, help="Run a specific scenario by ID")
    parser.add_argument("--api-key", type=str, help="OpenAI API key (or set OPENAI_API_KEY)")
    parser.add_argument("--model", "-m", type=str, default=None, help="Model to use (default: qwen2.5:7b)")
    parser.add_argument("--base-url", type=str, default=None, help="Ollama endpoint (default: http://localhost:11434/v1)")
    args = parser.parse_args()

    agent = ITAgent(api_key=args.api_key, model=args.model, base_url=args.base_url)

    if args.scenario:
        scenario = next((s for s in TEST_SCENARIOS if s.id == args.scenario), None)
        if not scenario:
            print(f"Scenario {args.scenario} not found. Available: {[s.id for s in TEST_SCENARIOS]}")
            sys.exit(1)
        results = [run_scenario(agent, scenario, verbose=args.verbose)]
    else:
        results = run_evaluation(agent, verbose=args.verbose)

    print_evaluation_report(results)
