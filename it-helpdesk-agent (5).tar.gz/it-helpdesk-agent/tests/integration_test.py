"""Integration test - validates agent reasoning without API key."""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.data.loader import get_data
from src.tools.registry import execute_tool

data = get_data()

# === Test 1: KB Search quality ===
print("=== Test 1: KB Search ===")
queries = [
    ("cannot login okta password locked", 2),
    ("VPN keeps disconnecting", 1),
    ("snowflake grafana access new employee", 1),
    ("jenkins build timeout", 1),
    ("printer jam", 1),
]
for query, min_results in queries:
    r = json.loads(execute_tool("search_knowledge_base", {"query": query}))
    ok = "PASS" if r["count"] >= min_results else "FAIL"
    print(f"  [{ok}] '{query}' -> {r['count']} articles (min {min_results})")
    for a in r["results"][:2]:
        print(f"       {a['id']}: {a['title']} (score={a['relevance_score']})")

# === Test 2: Service Status ===
print("\n=== Test 2: Service Status ===")
r = json.loads(execute_tool("check_service_status", {}))
degraded = [s for s in r["results"] if s["status"] != "operational"]
print(f"  Total services: {len(r['results'])}, Degraded: {len(degraded)}")
for s in r["results"]:
    icon = "🔴" if s["status"] != "operational" else "🟢"
    print(f"  {icon} {s['name']}: {s['status']}")
    if s.get("incident_details"):
        print(f"     {s['incident_details'][:80]}")

# === Test 3: User lookup ===
print("\n=== Test 3: User Lookup ===")
cases = [
    ("sarah.chen", True),
    ("EMP003", True),
    ("Marcus", True),
    ("nobody@nowhere.com", False),
    ("Alex Rivera", True),
]
for query, should_find in cases:
    r = json.loads(execute_tool("lookup_user", {"identifier": query}))
    found = r.get("found", False)
    ok = "PASS" if found == should_find else "FAIL"
    name = r.get("user", {}).get("name", "N/A") if found else "NOT FOUND"
    print(f"  [{ok}] '{query}' -> {name}")

# === Test 4: Access check ===
print("\n=== Test 4: Access Check ===")
checks = [
    ("EMP001", "Snowflake", True),
    ("EMP004", "Snowflake", False),
    ("EMP002", "Salesforce", True),
    ("EMP003", "Jenkins", True),
]
for user, system, expected in checks:
    r = json.loads(execute_tool("check_user_access", {"user_identifier": user, "system": system}))
    has = r.get("has_access", False)
    ok = "PASS" if has == expected else "FAIL"
    print(f"  [{ok}] {r.get('user', user)} -> {system}: {'has access' if has else 'no access'}")

# === Test 5: Resolution history ===
print("\n=== Test 5: Resolution History ===")
r = json.loads(execute_tool("search_resolution_history", {"query": "Jenkins build timeout"}))
print(f"  Found {r['count']} past resolutions")
for res in r["results"]:
    print(f"    {res['id']}: {res['issue']} (escalated={res['escalated']}, {res['resolution_time_minutes']}min)")

# === Test 6: Maintenance logs ===
print("\n=== Test 6: Maintenance Logs ===")
r = json.loads(execute_tool("get_maintenance_logs", {}))
for mw in r["maintenance_windows"]:
    print(f"  {mw['id']}: {mw['title']} ({mw['status']})")

# === Test 7: Conversation state ===
print("\n=== Test 7: Conversation State ===")
from src.utils.conversation import ConversationState
state = ConversationState(session_id="test-001")
state.add_message("user", "I can't log in")
state.add_message("assistant", "Let me help you.")
state.add_tool_call("search_knowledge_base")
state.set_user("EMP001")
state.set_issue("Okta login failure", "password")
state.add_diagnosis_step("Checked KB for login issues")
state.add_resolution_attempt("Suggested password reset flow")
ctx = state.get_context_summary()
print(f"  Session: {ctx['session_id']}")
print(f"  Turns: {ctx['turn_count']}, Tools: {ctx['tools_called']}")
print(f"  User: {ctx['identified_user']}, Issue: {ctx['identified_issue']}")

# Test escalation summary
from src.agent.core import ITAgent
os.environ["OPENAI_API_KEY"] = "test"
agent = ITAgent()
summary = agent.generate_escalation_summary(state)
has_sections = all(s in summary for s in ["Session ID", "Employee", "Investigation", "Resolution"])
print(f"  Escalation summary has all sections: {has_sections}")
print(f"  Summary length: {len(summary)} chars")

print("\n" + "=" * 50)
print("✅ All integration tests completed!")
