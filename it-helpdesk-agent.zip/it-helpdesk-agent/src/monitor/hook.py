"""
Monitor Hook - Captures tool calls, DB access, and escalation events.
Writes to a JSONL file that the monitor server reads.
"""
import json
import time
import os
import threading
from pathlib import Path
from datetime import datetime, timezone

EVENTS_FILE = Path(__file__).parent.parent.parent / "monitor" / "events.jsonl"
SESSION_FILE = Path(__file__).parent.parent.parent / "monitor" / "sessions.json"

_lock = threading.Lock()


def _ensure_dir():
    EVENTS_FILE.parent.mkdir(parents=True, exist_ok=True)


def _write_event(event: dict):
    """Append a single event to the JSONL file."""
    _ensure_dir()
    event["ts"] = time.time()
    event["time"] = datetime.now(timezone.utc).isoformat()
    with _lock:
        with open(EVENTS_FILE, "a") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")


def _update_sessions(session_id: str, delta: int):
    """Track active sessions count."""
    _ensure_dir()
    with _lock:
        sessions = {}
        if SESSION_FILE.exists():
            try:
                sessions = json.loads(SESSION_FILE.read_text())
            except Exception:
                sessions = {}
        sessions[session_id] = sessions.get(session_id, 0) + delta
        if sessions[session_id] <= 0:
            sessions.pop(session_id, None)
        SESSION_FILE.write_text(json.dumps(sessions))


def get_active_sessions() -> int:
    _ensure_dir()
    if not SESSION_FILE.exists():
        return 0
    try:
        return len(json.loads(SESSION_FILE.read_text()))
    except Exception:
        return 0


def get_events_since(since_ts: float = 0, limit: int = 200) -> list[dict]:
    """Read events newer than since_ts."""
    _ensure_dir()
    if not EVENTS_FILE.exists():
        return []
    events = []
    with open(EVENTS_FILE, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
                if ev.get("ts", 0) > since_ts:
                    events.append(ev)
            except Exception:
                continue
    return events[-limit:]


def clear_events():
    """Clear all events."""
    _ensure_dir()
    if EVENTS_FILE.exists():
        EVENTS_FILE.write_text("")
    if SESSION_FILE.exists():
        SESSION_FILE.write_text("{}")


# ── Public API for agent code ──

def on_session_start(session_id: str):
    _update_sessions(session_id, 1)
    _write_event({
        "type": "session_start",
        "session": session_id,
    })


def on_session_end(session_id: str):
    _update_sessions(session_id, -1)
    _write_event({
        "type": "session_end",
        "session": session_id,
    })


def on_tool_call(tool_name: str, arguments: dict, result: str, duration_ms: float, session_id: str = ""):
    """Record a tool call event."""
    # Map tool to database
    TOOL_DB_MAP = {
        "search_knowledge_base": "knowledge_base",
        "check_service_status": "service_status",
        "lookup_user": "user_directory",
        "check_user_access": "user_directory",
        "search_resolution_history": "resolution_history",
        "get_maintenance_logs": "service_status",
        "get_agent_policies": "policies",
    }
    db_name = TOOL_DB_MAP.get(tool_name, "unknown")

    _write_event({
        "type": "tool_call",
        "tool": tool_name,
        "args": arguments,
        "result_preview": result[:200] if result else "",
        "duration_ms": round(duration_ms, 1),
        "db": db_name,
        "session": session_id,
    })

    _write_event({
        "type": "db_read",
        "db": db_name,
        "tool": tool_name,
        "session": session_id,
    })


def on_user_message(message: str, session_id: str = ""):
    _write_event({
        "type": "user_message",
        "message": message[:300],
        "session": session_id,
    })


def on_agent_response(message: str, session_id: str = ""):
    _write_event({
        "type": "agent_response",
        "message": message[:300],
        "session": session_id,
    })


def on_escalation(escalation_data: dict, session_id: str = ""):
    """Record an escalation event with full context."""
    _write_event({
        "type": "escalation",
        "data": escalation_data,
        "session": session_id,
    })
