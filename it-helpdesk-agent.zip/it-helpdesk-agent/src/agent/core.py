"""
Agent Core - Main reasoning loop with tool orchestration.
"""
from __future__ import annotations
import json
import os
import time
import uuid
from typing import Optional

from openai import OpenAI

from src.tools.registry import TOOL_SCHEMAS, execute_tool
from src.utils.conversation import ConversationState
from src.monitor import hook as monitor


SYSTEM_PROMPT = """You are an expert IT Help Desk Agent for a company. You help employees resolve their IT issues through conversation.

## Your Role
- You are the FIRST point of contact for all IT issues
- You speak like a knowledgeable, friendly IT colleague — not a robot
- You diagnose issues step by step, asking clarifying questions when needed
- You use tools to gather information before offering solutions
- You are honest about what you can and cannot do

## How You Work

### 1. Understand the Problem
- Ask clarifying questions if the issue is vague
- Identify the user (you'll need their info for some lookups)
- Categorize the issue (password/VPN/software/access/hardware/devops)

### 2. Investigate
- Search the knowledge base for relevant articles
- Check service status for any active incidents
- Look up the user's info and access if relevant
- Check resolution history for similar past issues
- Check recent maintenance logs if timing is suspicious

### 3. Diagnose & Resolve
- Form a hypothesis based on your investigation
- Provide step-by-step guidance from knowledge base articles
- If there's a known service incident, inform the user and provide workarounds
- Track what you've tried and what worked

### 4. Know Your Limits
You CAN: provide troubleshooting steps, check status, look up info, explain processes
You CANNOT: reset passwords, modify access, restart services, make infrastructure changes

If the issue requires actions you cannot perform, explain what needs to happen and offer to escalate.

## Escalation
Escalate to a human IT specialist when:
- You've tried all relevant troubleshooting and the issue persists
- The issue requires system changes you can't make (password reset, account unlock)
- Multiple users are affected (potential infrastructure issue)
- The user explicitly asks for a human after you've helped
- It's a security incident or suspected breach

When escalating, provide a COMPLETE context summary so the human doesn't need to ask the user to repeat everything.

## Communication Style
- Be concise but thorough
- Use numbered steps for instructions
- Acknowledge urgency when expressed
- Don't apologize excessively — focus on solving
- If you're unsure, say so clearly
- Never fabricate solutions or make up information

## Data Privacy
- Only look up user information when necessary for the support request
- Don't share one user's private info with another
- Treat all internal systems info as confidential
"""


class ITAgent:
    """The IT Help Desk Agent - orchestrates conversation and tool use."""

    # Ollama defaults (OpenAI-compatible endpoint)
    DEFAULT_BASE_URL = "http://localhost:11434/v1"
    DEFAULT_MODEL = "qwen2.5:7b"
    DEFAULT_API_KEY = "ollama"  # Ollama doesn't require auth, any string works

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None, base_url: Optional[str] = None):
        self.base_url = base_url or os.environ.get("OPENAI_BASE_URL", self.DEFAULT_BASE_URL)
        self.model = model or os.environ.get("AGENT_MODEL", self.DEFAULT_MODEL)
        self.client = OpenAI(
            api_key=api_key or os.environ.get("OPENAI_API_KEY", self.DEFAULT_API_KEY),
            base_url=self.base_url,
        )
        self.max_tool_rounds = 10  # Safety limit on tool call loops

    def new_session(self) -> ConversationState:
        session_id = str(uuid.uuid4())[:8]
        monitor.on_session_start(session_id)
        return ConversationState(session_id=session_id)

    def chat(self, state: ConversationState, user_message: str) -> str:
        """Process a user message and return the agent's response."""
        # Add user message to history
        state.add_message("user", user_message)
        monitor.on_user_message(user_message, state.session_id)

        # Build the messages for the API call
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        # Add conversation context summary as a system message if this isn't the first turn
        if state.turn_count > 1:
            context = state.get_context_summary()
            context_msg = f"[Session Context: {json.dumps(context)}]"
            messages.append({"role": "system", "content": context_msg})

        # Add conversation history
        messages.extend(state.messages)

        # Agent loop - may involve multiple tool calls
        for round_num in range(self.max_tool_rounds):
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=TOOL_SCHEMAS,
                tool_choice="auto",
                temperature=0.3,
                max_tokens=2000,
            )

            assistant_message = response.choices[0].message

            # If no tool calls, we're done - return the response
            if not assistant_message.tool_calls:
                final_response = assistant_message.content or ""
                state.add_message("assistant", final_response)
                monitor.on_agent_response(final_response, state.session_id)
                return final_response

            # Process tool calls
            state.add_message("assistant", assistant_message.content or "", tool_calls=[
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.function.name, "arguments": tc.function.arguments}
                }
                for tc in assistant_message.tool_calls
            ])

            # Add assistant message to the API messages too
            messages.append(assistant_message)

            # Execute each tool call and add results
            for tool_call in assistant_message.tool_calls:
                tool_name = tool_call.function.name
                tool_args = json.loads(tool_call.function.arguments)

                # Track tool usage
                state.add_tool_call(tool_name)

                # Execute with timing
                t0 = time.time()
                result = execute_tool(tool_name, tool_args)
                duration_ms = (time.time() - t0) * 1000

                # Monitor hook
                monitor.on_tool_call(tool_name, tool_args, result, duration_ms, state.session_id)

                # Add tool result to conversation
                tool_msg = {
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result
                }
                state.messages.append(tool_msg)
                messages.append(tool_msg)

        # If we exhausted all rounds, return a fallback
        fallback = "I've gathered a lot of information but need to summarize. Let me provide what I've found so far."
        state.add_message("assistant", fallback)
        return fallback

    def generate_escalation_summary(self, state: ConversationState) -> str:
        """Generate a structured escalation summary for human handoff."""
        summary_parts = [
            "## 🎫 IT Support Escalation Summary\n",
            f"**Session ID:** {state.session_id}",
            f"**Turns:** {state.turn_count}",
        ]

        if state.identified_user:
            summary_parts.append(f"**Employee:** {state.identified_user}")
        if state.identified_issue:
            summary_parts.append(f"**Issue:** {state.identified_issue}")
        if state.issue_category:
            summary_parts.append(f"**Category:** {state.issue_category}")

        summary_parts.append(f"**Confidence:** {state.confidence_level}")

        if state.diagnosis_steps:
            summary_parts.append("\n### Investigation Steps")
            for i, step in enumerate(state.diagnosis_steps, 1):
                summary_parts.append(f"{i}. {step}")

        if state.resolution_attempted:
            summary_parts.append("\n### Resolution Attempts")
            for i, attempt in enumerate(state.resolution_attempted, 1):
                summary_parts.append(f"{i}. {attempt}")

        tools_used = list(set(state.tools_called))
        if tools_used:
            summary_parts.append(f"\n### Tools Used: {', '.join(tools_used)}")

        summary_parts.append("\n### Conversation Transcript (last 5 messages)")
        recent = state.messages[-5:] if len(state.messages) > 5 else state.messages
        for msg in recent:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if content and role in ("user", "assistant"):
                summary_parts.append(f"**{role.title()}:** {content[:200]}")

        summary = "\n".join(summary_parts)

        # Monitor: record escalation
        monitor.on_escalation({
            "user": state.identified_user or "Unknown",
            "issue": state.identified_issue or "Unknown issue",
            "category": state.issue_category or "unknown",
            "priority": "high" if state.confidence_level == "low" else "medium",
            "reason": "Agent unable to resolve - escalating to human",
            "tools": tools_used,
            "diagnosis": state.diagnosis_steps,
            "transcript": "\n".join(
                f"{'👤' if m.get('role') == 'user' else '🤖'} {m.get('content', '')[:150]}"
                for m in recent if m.get("content") and m.get("role") in ("user", "assistant")
            ),
            "turns": state.turn_count,
        }, state.session_id)

        return summary
