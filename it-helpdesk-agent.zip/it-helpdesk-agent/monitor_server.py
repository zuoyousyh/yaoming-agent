"""
Monitor Server - Serves the dashboard HTML and provides a real-time event API.

Usage:
    python monitor_server.py [--port 8765]

Then open http://localhost:8765 in your browser.
The agent writes events to monitor/events.jsonl,
this server reads them and serves via API to the dashboard.
"""
import http.server
import json
import os
import sys
import argparse
import time
from pathlib import Path
from urllib.parse import urlparse, parse_qs

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
from src.monitor.hook import get_events_since, get_active_sessions, clear_events

BASE_DIR = Path(__file__).parent
DASHBOARD_HTML = BASE_DIR / "monitor.html"
MONITOR_DIR = BASE_DIR / "monitor"


class MonitorHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            self._serve_html()
        elif path == "/api/events":
            self._serve_events(params)
        elif path == "/api/sessions":
            self._serve_sessions()
        elif path == "/api/clear":
            self._serve_clear()
        elif path == "/api/stats":
            self._serve_stats()
        else:
            self._404()

    def _serve_html(self):
        if not DASHBOARD_HTML.exists():
            self._send_text(404, "monitor.html not found")
            return
        content = DASHBOARD_HTML.read_text(encoding="utf-8")
        self._send_html(200, content)

    def _serve_events(self, params):
        since = float(params.get("since", ["0"])[0])
        limit = int(params.get("limit", ["200"])[0])
        events = get_events_since(since, limit)
        self._send_json(200, {
            "events": events,
            "server_time": time.time(),
            "active_sessions": get_active_sessions(),
        })

    def _serve_sessions(self):
        self._send_json(200, {"active_sessions": get_active_sessions()})

    def _serve_clear(self):
        clear_events()
        self._send_json(200, {"ok": True, "message": "Events cleared"})

    def _serve_stats(self):
        events = get_events_since(0, 10000)
        tool_counts = {}
        db_counts = {}
        escalation_count = 0
        response_times = []

        for ev in events:
            if ev.get("type") == "tool_call":
                tool = ev.get("tool", "unknown")
                tool_counts[tool] = tool_counts.get(tool, 0) + 1
                db = ev.get("db", "unknown")
                db_counts[db] = db_counts.get(db, 0) + 1
                if ev.get("duration_ms"):
                    response_times.append(ev["duration_ms"])
            elif ev.get("type") == "db_read":
                db = ev.get("db", "unknown")
                db_counts[db] = db_counts.get(db, 0) + 1
            elif ev.get("type") == "escalation":
                escalation_count += 1

        avg_ms = round(sum(response_times) / len(response_times), 1) if response_times else 0

        self._send_json(200, {
            "total_tool_calls": sum(tool_counts.values()),
            "total_db_queries": sum(db_counts.values()),
            "total_escalations": escalation_count,
            "active_sessions": get_active_sessions(),
            "avg_response_ms": avg_ms,
            "tool_counts": tool_counts,
            "db_counts": db_counts,
        })

    def _404(self):
        self._send_text(404, "Not Found")

    def _send_html(self, code, content):
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(content.encode("utf-8"))

    def _send_json(self, code, data):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def _send_text(self, code, text):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(text.encode("utf-8"))

    def log_message(self, format, *args):
        # Suppress default logging
        pass


def main():
    parser = argparse.ArgumentParser(description="Yaoming Agent Monitor Server")
    parser.add_argument("--port", type=int, default=8765, help="Port to listen on")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    args = parser.parse_args()

    # Ensure monitor dir exists
    MONITOR_DIR.mkdir(parents=True, exist_ok=True)

    server = http.server.HTTPServer((args.host, args.port), MonitorHandler)
    print(f"""
╔══════════════════════════════════════════════════╗
║  🖥️  Yaoming Agent Monitor Server               ║
║                                                  ║
║  Dashboard:  http://localhost:{args.port}            ║
║  Events API: http://localhost:{args.port}/api/events  ║
║  Stats API:  http://localhost:{args.port}/api/stats   ║
║                                                  ║
║  Press Ctrl+C to stop                            ║
╚══════════════════════════════════════════════════╝
""")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nMonitor server stopped.")
        server.server_close()


if __name__ == "__main__":
    main()
