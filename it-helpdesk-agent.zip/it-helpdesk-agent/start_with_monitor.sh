#!/bin/bash
# Start the IT Help Desk Agent with the Monitor Server
# Usage: bash start_with_monitor.sh

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "╔══════════════════════════════════════════════════╗"
echo "║  🚀 Starting Yaoming Agent + Monitor            ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Ensure monitor directory exists
mkdir -p monitor

# Start monitor server in background
echo "📡 Starting monitor server on port 8765..."
python3 monitor_server.py --port 8765 &
MONITOR_PID=$!
sleep 1

# Check if monitor server started
if kill -0 $MONITOR_PID 2>/dev/null; then
    echo "✅ Monitor server running (PID: $MONITOR_PID)"
    echo "   Dashboard: http://localhost:8765"
else
    echo "⚠️  Monitor server failed to start (port may be in use)"
fi

echo ""

# Start the agent
echo "🤖 Starting IT Help Desk Agent..."
echo "   (Monitor will capture all tool calls, DB queries, and escalations)"
echo ""
python3 main.py

# Cleanup
kill $MONITOR_PID 2>/dev/null
echo "Monitor server stopped."
